#!/bin/bash
if [ "${JGA_USER}" != "" -o "${JGA_PASSWORD}" != "" ] ; then
    printf "overwrite JGA login user name and password.\n"
fi
read -p "JGA login user name : " loginUser
export JGA_USER="${loginUser}"
read -sp "JGA Login password  : " loginPassword
echo ""
export JGA_PASSWORD="${loginPassword}"
if [ "${JGA_USER}" = "" ]; then
    printf "WARNING: JGA login user name is empty.\n"
fi
if [ "${JGA_PASSWORD}" = "" ]; then
    printf "WARNING: JGA login password is empty.\n"
fi
