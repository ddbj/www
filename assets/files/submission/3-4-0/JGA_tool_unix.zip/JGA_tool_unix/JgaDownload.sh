#!/bin/bash

allParam="${@}"

# helpとversionが含まれている場合、ユーザーとパスワードは入力させない
skipUserPassword=0
for OPT in "$@"; do
    case $OPT in
        '-h'|'--help' )
            skipUserPassword=1
            ;;
        '-v'|'--version' )
            skipUserPassword=1
            ;;
    esac
    shift
done

setUserHere=0
if [ ${skipUserPassword} -eq 0 -a "${JGA_USER}" = "" ] ; then
    read -p "JGA login user name : " loginUser
    export JGA_USER="${loginUser}"
    setUserHere=1
fi
setPasswordHere=0
if [ ${skipUserPassword} -eq 0 -a "${JGA_PASSWORD}" = "" ] ; then
    read -sp "JGA Login Password  : " loginPassword
    echo ""
    export JGA_PASSWORD="${loginPassword}"
    setPasswordHere=1
fi
java -Xmx1024M -Djsse.enableSNIExtension=false -Djavax.xml.parsers.DocumentBuilderFactory=com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl -Djavax.xml.parsers.SAXParserFactory=com.sun.org.apache.xerces.internal.jaxp.SAXParserFactoryImpl -classpath jga.jar jp.ac.nig.ddbj.jga.egyptian.cli.CliDownloadMain ${allParam}
rc=${?}
if [ ${setUserHere} -eq 1 ]; then
    unset JGA_USER
fi
if [ ${setPasswordHere} -eq 1 ]; then
    unset JGA_PASSWORD
fi
exit ${rc}
