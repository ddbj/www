#! /bin/sh

java -classpath jar/agd-data-encrypt.jar -Dhost=`hostname` jp.ac.nig.ddbj.jga.foldex.CipherMain $*
