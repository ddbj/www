#! /bin/sh

java -classpath jar/jga-data-encrypt.jar -Dhost=`hostname` jp.ac.nig.ddbj.jga.foldex.CipherMain $*
