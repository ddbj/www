#! /bin/sh

MAXMEM=512M
java -Xmx${MAXMEM} -jar lib/UME.jar
